'''
Search related functions for Assignment 4.
'''

def sort1000(t):
    # complete this function


def min_val(t):
    # complete this function